import static net.sf.importthem.handlers.Util.*
seekProjects(projectMap,selection)
